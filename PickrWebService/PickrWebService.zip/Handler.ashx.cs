﻿using JsonServices.Web;
using JsonServices;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Collections.Generic;
using System;
using System.Timers;
using System.Web;

namespace JSONWebService
{
    /// <summary>
    /// Summary description for Handler
    /// </summary>
    public class Handler : JsonHandler
    {
        
        public Handler()
        {
            this.service.Name = "JSONWebService";
            this.service.Description = "Pickr JSON Web Service";
            InterfaceConfiguration IConfig = new InterfaceConfiguration("PickrWebService", typeof(IServiceAPI), typeof(ServiceAPI));
            this.service.Interfaces.Add(IConfig);


            //if(HttpContext.Current.Items["Email"] != null)
            //{
            //    string email = (string)HttpContext.Current.Items["Email"];
            //}
        }
        

    }
}